-- Q9. Find maximum values of confirmed, deaths, recovered per year

SELECT 
    EXTRACT(MONTH FROM Date) AS month,
    max(Confirmed) AS most_frequent_confirmed,
    max(Deaths) AS most_frequent_deaths,
    max(Recovered) AS most_frequent_recovered
FROM 
    corona_virus_dataset
GROUP BY 
    EXTRACT(MONTH FROM Date);


