-- Q3. check total number of rows
SELECT COUNT(*) AS total_rows FROM corona_virus_dataset ;
