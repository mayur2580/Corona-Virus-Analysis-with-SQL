-- Q13. Check how corona virus spread out with respect to recovered case
--      (Eg.: total confirmed cases, their average, variance & STDEV )

-- Calculate total recovered cases
SELECT SUM(Recovered) AS total_recovered_cases
FROM corona_virus_dataset;

-- Calculate average recovered cases
SELECT AVG(Recovered) AS average_recovered_cases
FROM corona_virus_dataset;

-- Calculate variance of recovered cases
SELECT VARIANCE(Recovered) AS variance_recovered_cases
FROM corona_virus_dataset;

-- Calculate standard deviation of recovered cases
SELECT STDDEV(Recovered) AS stdev_recovered_cases
FROM corona_virus_dataset;
