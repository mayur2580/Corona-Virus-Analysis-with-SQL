-- Q14. Find Country having highest number of the Confirmed case

SELECT 
    `Country/Region`, Confirmed
FROM
    corona_virus_dataset
WHERE
    Confirmed = (SELECT 
            MAX(Confirmed)
        FROM
            corona_virus_dataset);

