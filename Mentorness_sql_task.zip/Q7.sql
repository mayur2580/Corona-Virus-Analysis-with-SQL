-- Q7. Find most frequent value for confirmed, deaths, recovered each month 

SELECT 
    EXTRACT(MONTH FROM Date) AS month,
    max(Confirmed) AS most_frequent_confirmed,
    max(Deaths) AS most_frequent_deaths,
    max(Recovered) AS most_frequent_recovered
FROM 
    corona_virus_dataset
GROUP BY 
    EXTRACT(MONTH FROM Date);
