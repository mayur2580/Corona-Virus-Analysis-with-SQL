-- Q5. Number of month present in dataset
SELECT COUNT(DISTINCT EXTRACT(MONTH FROM STR_TO_DATE(Date, '%d-%m-%Y'))) AS num_months
FROM corona_virus_dataset ;


